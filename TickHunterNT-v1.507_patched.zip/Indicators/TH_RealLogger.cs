﻿using System;
using NinjaTrader.Code;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealLogger
    {
        private string systemName = String.Empty;
        private int lastPrintOutputHashCode = 0;
        private const int delaySeconds = 1;
        private DateTime lastCheckTime = DateTime.MinValue;
        private DateTime lastRunTime = DateTime.MinValue;
        public RealLogger(string systemName)
        {
            this.systemName = systemName;
        }

        public void PrintOutput(string output, PrintTo outputTab = PrintTo.OutputTab1, bool blockDuplicateMessages = false, bool throttleEverySecond = false)
        {
            bool outputNow = true;

            if (throttleEverySecond)
            {
                lastCheckTime = DateTime.Now;

                if (lastCheckTime > lastRunTime)
                { outputNow = true; }
                else
                { outputNow = false; }
            }

            if (outputNow)
            {
                if (blockDuplicateMessages)
                {
                    int tempHashCode = output.GetHashCode();
                    if (tempHashCode != lastPrintOutputHashCode)
                    {
                        lastPrintOutputHashCode = tempHashCode;
                        lastRunTime = DateTime.Now.AddSeconds(delaySeconds);
                        Output.Process(DateTime.Now + " " + systemName + ": " + output, outputTab);
                    }
                }
                else
                {
                    lastRunTime = DateTime.Now.AddSeconds(delaySeconds);
                    Output.Process(DateTime.Now + " " + systemName + ": " + output, outputTab);
                }
            }
        }
    }
}
