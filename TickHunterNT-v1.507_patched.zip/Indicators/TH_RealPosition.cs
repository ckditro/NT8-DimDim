﻿using NinjaTrader.Cbi;
using System;
using System.Threading;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealPosition
    {
        private const int StateHasChanged = 1;
        private const int StateHasNotChanged = 0;
        private int stateChangeStatus = StateHasChanged;

        private string positionId = null;
        private bool isValid = true;
        private MarketPosition marketPosition = MarketPosition.Flat;
        private double averagePrice = 0;
        private Instrument instrument = null;
        private int quantity = 0;
        private Account account = null;
        private DateTime createDate = DateTime.MinValue;
        private DateTime modifyDate = DateTime.MinValue;

        public RealPosition()
        {
            this.positionId = Guid.NewGuid().ToString();
        }

        public string PositionId
        {
            get
            {
                return positionId;
            }
        }

        public bool IsValid
        {
            get
            {
                return isValid;
            }
            set
            {
                ChangeStateFlag();
                isValid = value;
            }
        }

        public Account Account
        {
            get
            {
                return account;
            }
            set
            {
                ChangeStateFlag();
                account = value;
            }
        }

        public MarketPosition MarketPosition
        {
            get
            {
                return marketPosition;
            }
            set
            {
                ChangeStateFlag();
                marketPosition = value;
            }
        }

        public double AveragePrice
        {
            get
            {
                return averagePrice;
            }
            set
            {
                ChangeStateFlag();
                averagePrice = value;
            }
        }

        public Instrument Instrument
        {
            get
            {
                return instrument;
            }
            set
            {
                ChangeStateFlag();
                instrument = value;
            }
        }

        public int Quantity
        {
            get
            {
                return quantity;
            }
            set
            {
                ChangeStateFlag();
                quantity = value;
            }
        }

        public DateTime CreateDate
        {
            get
            {
                return createDate;
            }
            set
            {
                ChangeStateFlag();
                createDate = value;
            }
        }

        public DateTime ModifyDate
        {
            get
            {
                return modifyDate;
            }
            set
            {
                ChangeStateFlag();
                modifyDate = value;
            }
        }

        public bool IsFlat()
        {
            return (marketPosition == MarketPosition.Flat || quantity == 0);
        }

        public bool HasStateChanged()
        {
            return (stateChangeStatus == StateHasChanged);
        }

        public void StoreState()
        {
            ResetStateFlag();
        }

        private void ChangeStateFlag()
        {
            Interlocked.Exchange(ref stateChangeStatus, StateHasChanged);
        }

        private void ResetStateFlag()
        {
            Interlocked.Exchange(ref stateChangeStatus, StateHasNotChanged);
        }
    }
}
