﻿using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript.Indicators.TickHunterTA.TH;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealOrderService
    {
        private readonly Dictionary<string, int> orderPartialFillCache = new Dictionary<string, int>();
        public readonly object OrderPartialFillCacheLock = new object();
        private readonly RealMultiCycleCache orderUpdateMultiCycleCache = new RealMultiCycleCache();

        private readonly List<RealOrder> realOrders = new List<RealOrder>();
        private readonly object realOrderLock = new object();
        private const string TargetOrderName = "Target";
        private const string StopOrderName = "Stop";
        private const string EntryOrderName = "Entry";
        private const string ExitOrderName = "Exit";

        private const int InOrderUpdateCycleFinishedStatus = 0;
        private int inOrderUpdateCycleCounter = 0;

        public int OrderCount
        {
            get 
            { 
                lock (realOrderLock)
                {
                    return realOrders.Count; 
                }
            }
        }

        public void InOrderUpdateCycleIncrement()
        {
            Interlocked.Increment(ref inOrderUpdateCycleCounter);
        }

        public void InOrderUpdateCycleDecrement()
        {
            Interlocked.Decrement(ref inOrderUpdateCycleCounter);
        }

        public bool InOrderUpdateCycle()
        {
            return (inOrderUpdateCycleCounter > InOrderUpdateCycleFinishedStatus);
        }

        public bool IsValidOrder(RealOrder order, Instrument instrument)
        {
            bool returnFlag = false;

            if (order.Instrument.FullName == instrument.FullName && order.OrderType != OrderType.Unknown)
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public Dictionary<string, int> OrderPartialFillCache
        {
            get 
            { 
                // Return a snapshot copy for thread safety
                lock (OrderPartialFillCacheLock)
                {
                    return new Dictionary<string, int>(orderPartialFillCache);
                }
            }
        }

        public RealMultiCycleCache OrderUpdateMultiCycleCache
        {
            get { return orderUpdateMultiCycleCache; }
        }

        public string BuildOrderUniqueId(long orderId)
        {
            string keyName = orderId.ToString();

            return keyName;
        }

        public string BuildEntryOrderName()
        {
            string keyName = EntryOrderName;

            return keyName;
        }

        public string BuildExitOrderName()
        {
            string keyName = ExitOrderName;

            return keyName;
        }

        public string BuildTargetOrderName()
        {
            string keyName = TargetOrderName;

            return keyName;
        }

        public string BuildStopOrderName()
        {
            string keyName = StopOrderName;

            return keyName;
        }

        public bool TryGetByIndex(int index, out RealOrder realOrder)
        {
            bool returnFlag = false;
            realOrder = null;

            lock (realOrderLock)
            {
                try
                {
                    if (index >= 0 && index < realOrders.Count)
                    {
                        realOrder = realOrders[index];
                        returnFlag = true;
                    }
                }
                catch
                {
                    //stuff exception 
                }
            }

            return returnFlag;
        }

        public bool TryGetById(long orderId, out RealOrder realOrder)
        {
            bool returnFlag = false;
            realOrder = null;

            lock (realOrderLock)
            {
                try
                {
                    RealOrder tempRealOrder;
                    // Use for loop with direct indexing instead of ElementAt - more thread-safe than foreach
                    for (int index = 0; index < realOrders.Count; index++)
                    {
                        tempRealOrder = realOrders[index];

                        if (tempRealOrder != null && tempRealOrder.OrderId == orderId)
                        {
                            realOrder = tempRealOrder;
                            returnFlag = true;
                            break;
                        }
                    }
                }
                catch
                {
                    //stuff exception 
                }
            }

            return returnFlag;
        }

        public RealOrder BuildRealOrder(Account account, Instrument instrument, long orderId, string exchangeOrderId, string name, OrderType orderType, OrderAction orderAction, int quantity, int quantityChanged,
            double limitPrice, double limitPriceChanged, double stopPrice, double stopPriceChanged,
            OrderState orderState, int quantityFilled)
        {
            RealOrder realOrder = new RealOrder();
            realOrder.Account = account;
            realOrder.Instrument = instrument;
            realOrder.OrderId = orderId;
            realOrder.ExchangeOrderId = exchangeOrderId;
            realOrder.Name = name;
            realOrder.OrderType = orderType;
            realOrder.OrderAction = orderAction;
            realOrder.Quantity = quantity;
            realOrder.QuantityChanged = quantityChanged;
            realOrder.QuantityFilled = quantityFilled;
            realOrder.LimitPrice = limitPrice;
            realOrder.LimitPriceChanged = limitPriceChanged;
            realOrder.StopPrice = stopPrice;
            realOrder.StopPriceChanged = stopPriceChanged;
            realOrder.OrderState = orderState;

            return realOrder;
        }

        public void RemoveOrder(long orderId)
        {
            RealOrder foundOrder = null;
            lock (realOrderLock)
            {
                if (TryGetById(orderId, out foundOrder))
                {
                    realOrders.Remove(foundOrder);
                }
            }
        }
        public void RemoveAllTerminalStateOrders()
        {
            List<RealOrder> removeOrderList = new List<RealOrder>();

            lock (realOrderLock)
            {
                RealOrder tempRealOrder;
                // Use for loop with direct indexing instead of ElementAt - more thread-safe than foreach
                for (int index = 0; index < realOrders.Count; index++)
                {
                    tempRealOrder = realOrders[index];

                    if (tempRealOrder != null && Order.IsTerminalState(tempRealOrder.OrderState))
                    {
                        removeOrderList.Add(tempRealOrder);
                    }
                }

                foreach (RealOrder removeOrder in removeOrderList)
                {
                    realOrders.Remove(removeOrder);
                }

            }
        }

        public int AddOrUpdateOrder(RealOrder order)
        {
            int orderQuantityRemaining = 0;

            lock (realOrderLock)
            {
                RealOrder foundOrder = null;

                if (TryGetById(order.OrderId, out foundOrder))
                {
                    foundOrder.ExchangeOrderId = order.ExchangeOrderId;
                    foundOrder.Quantity = order.Quantity;
                    foundOrder.QuantityChanged = order.QuantityChanged;
                    foundOrder.StopPrice = order.StopPrice;
                    foundOrder.StopPriceChanged = order.StopPriceChanged;
                    foundOrder.LimitPrice = order.LimitPrice;
                    foundOrder.LimitPriceChanged = order.LimitPriceChanged;
                    
                    // Prevent out-of-order event updates: only update state if it's more advanced
                    // Use filled quantity as primary indicator of event recency
                    bool shouldUpdateState = ShouldUpdateOrderState(foundOrder.OrderState, foundOrder.QuantityFilled, 
                        order.OrderState, order.QuantityFilled);
                    
                    if (shouldUpdateState)
                    {
                        foundOrder.OrderState = order.OrderState;
                        foundOrder.QuantityFilled = order.QuantityFilled;
                    }
                    else if (order.QuantityFilled > foundOrder.QuantityFilled)
                    {
                        // Filled quantity increased, update it even if state seems older
                        foundOrder.QuantityFilled = order.QuantityFilled;
                        // If filled increased, state should be PartFilled or Filled
                        if (order.OrderState == OrderState.PartFilled || order.OrderState == OrderState.Filled)
                        {
                            foundOrder.OrderState = order.OrderState;
                        }
                    }
                    
                    foundOrder.OrderAction = order.OrderAction;

                    orderQuantityRemaining = foundOrder.Quantity;
                }
                else
                {
                    realOrders.Add(order);

                    orderQuantityRemaining = order.Quantity;
                }
            }

            return orderQuantityRemaining;
        }

        private bool ShouldUpdateOrderState(OrderState currentState, int currentFilled, OrderState newState, int newFilled)
        {
            // Always update if new state is terminal (Filled, Cancelled, Rejected)
            if (Order.IsTerminalState(newState))
            {
                // Don't overwrite terminal states with other terminal states unless it's a progression
                if (Order.IsTerminalState(currentState))
                {
                    // Filled is more final than Cancelled for filled orders
                    if (newState == OrderState.Filled && currentState != OrderState.Filled)
                        return true;
                    // Otherwise, keep current terminal state
                    return false;
                }
                // Current is not terminal, new is terminal - always update
                return true;
            }

            // Don't overwrite terminal states with non-terminal states
            if (Order.IsTerminalState(currentState))
                return false;

            // If new filled quantity is greater, it's definitely a newer event
            if (newFilled > currentFilled)
                return true;

            // If filled quantities are equal, prefer more advanced states
            if (newFilled == currentFilled)
            {
                // PartFilled is more advanced than Working/Accepted
                if (newState == OrderState.PartFilled && 
                    (currentState == OrderState.Working || currentState == OrderState.Accepted))
                    return true;
                
                // Filled is more advanced than PartFilled
                if (newState == OrderState.Filled && currentState == OrderState.PartFilled)
                    return true;
            }

            // If new filled is less, it's likely an older event - don't update
            if (newFilled < currentFilled)
                return false;

            // For same filled quantity, only update if new state is clearly more advanced
            // Don't regress from PartFilled to Working/Accepted
            if (currentState == OrderState.PartFilled && 
                (newState == OrderState.Working || newState == OrderState.Accepted))
                return false;

            // Default: allow update for other state transitions
            return true;
        }

        public void LoadOrders(Account account, int positionCount)
        {
            lock (realOrderLock)
            {
                lock (account.Orders)
                {
                    realOrders.Clear();

                    foreach (Order orderItem in account.Orders)
                    {
                        //if (positionCount != 0 || (positionCount == 0 && !Order.IsTerminalState(orderItem.OrderState)))
                        if (!Order.IsTerminalState(orderItem.OrderState))
                        {
                            RealOrder order = BuildRealOrder(account,
                                orderItem.Instrument,
                                orderItem.Id,
                                orderItem.OrderId,
                                orderItem.Name,
                                orderItem.OrderType,
                                orderItem.OrderAction,
                                orderItem.Quantity,
                                orderItem.QuantityChanged,
                                orderItem.LimitPrice,
                                orderItem.LimitPriceChanged,
                                orderItem.StopPrice,
                                orderItem.StopPriceChanged,
                                orderItem.OrderState,
                                orderItem.Filled);

                            AddOrUpdateOrder(order);
                        }
                    }
                }
            }
        }

        public double GetStopLossInfo(Account account, Instrument instrument, OrderAction orderAction, out OrderType orderType, out int orderQuantity, out int orderCount)
        {
            double stopLossPrice = 0;
            orderType = OrderType.Unknown;
            orderQuantity = 0;
            orderCount = 0;

            // Lock once and iterate to avoid TOCTOU issues
            lock (realOrderLock)
            {
                RealOrder order;
                // Use for loop with direct indexing instead of ElementAt - more thread-safe than foreach
                for (int index = 0; index < realOrders.Count; index++)
                {
                    try
                    {
                        order = realOrders[index];

                        if (order != null && RealOrderService.IsValidStopLossOrder(order, instrument, orderAction))
                        {
                            stopLossPrice = order.StopPrice;
                            orderType = order.OrderType;
                            orderQuantity += order.QuantityRemaining;
                            orderCount++;
                        }
                    }
                    catch
                    {
                        //stuff exception
                    }
                }
            }

            return stopLossPrice;
        }

        public double GetTakeProfitInfo(Account account, Instrument instrument, OrderAction orderAction, out OrderType orderType, out int orderQuantity, out int orderCount)
        {
            double takeProfitPrice = 0;
            orderType = OrderType.Unknown;
            orderQuantity = 0;
            orderCount = 0;

            // Lock once and iterate to avoid TOCTOU issues
            lock (realOrderLock)
            {
                RealOrder order;
                // Use for loop with direct indexing instead of ElementAt - more thread-safe than foreach
                for (int index = 0; index < realOrders.Count; index++)
                {
                    try
                    {
                        order = realOrders[index];

                        if (order != null && RealOrderService.IsValidTakeProfitOrder(order, instrument, orderAction))
                        {
                            takeProfitPrice = order.LimitPrice;
                            orderType = order.OrderType;
                            orderQuantity += order.QuantityRemaining;
                            orderCount++;
                        }
                    }
                    catch
                    {
                        //stuff exception
                    }
                }
            }

            return takeProfitPrice;
        }
        public void SubmitLimitOrder(Account account, Order limitOrder)
        {
            //double price = limitOrder.

            //account.Submit(new[] { limitOrder });
        }

        public static bool IsValidStopLossPrice(Instrument instrument, OrderAction orderAction, double price, double lastPrice)
        {
            bool returnFlag = false;

            if (orderAction == OrderAction.BuyToCover && price > lastPrice)
            {
                returnFlag = true;
            }
            else if (orderAction == OrderAction.Sell && price < lastPrice)
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidTakeProfitPrice(Instrument instrument, OrderAction orderAction, double price, double lastPrice)
        {
            bool returnFlag = false;

            if (orderAction == OrderAction.BuyToCover && price < lastPrice)
            {
                returnFlag = true;
            }
            else if (orderAction == OrderAction.Sell && price > lastPrice)
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidStopLossOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsStopMarket && order.Name.StartsWith(StopOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }
        public static bool IsValidTakeProfitOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsLimit && order.Name.StartsWith(TargetOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidSellStopOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsStopMarket && order.Name.StartsWith(EntryOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidBuyStopOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsStopMarket && order.Name.StartsWith(EntryOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidSellLimitOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsLimit && order.Name.StartsWith(EntryOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsValidBuyLimitOrder(RealOrder order, Instrument instrument, OrderAction orderAction)
        {
            bool returnFlag = false;

            if (!Order.IsTerminalState(order.OrderState) && order.OrderAction == orderAction && order.Instrument == instrument && order.IsLimit && order.Name.StartsWith(EntryOrderName))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public int GetFilledOrderQuantity(long orderId, OrderState orderState, int orderFilled)
        {
            int quantity = orderFilled;

            if (orderState == OrderState.PartFilled || orderState == OrderState.Filled)
            {
                lock (OrderPartialFillCacheLock)
                {
                    string orderUniqueId = BuildOrderUniqueId(orderId);
                    if (orderPartialFillCache.ContainsKey(orderUniqueId))
                    {
                        int currentFilledQuantity = orderPartialFillCache[orderUniqueId];

                        quantity = orderFilled - currentFilledQuantity;

                        if (orderState == OrderState.Filled)
                            orderPartialFillCache.Remove(orderUniqueId);
                        else
                            orderPartialFillCache[orderUniqueId] = orderFilled;
                    }
                    else
                    {
                        if (orderState == OrderState.PartFilled)
                            orderPartialFillCache[orderUniqueId] = orderFilled;
                    }
                }
            }

            return quantity;
        }

        public bool AreAllOrderUpdateCyclesComplete()
        {
            bool returnFlag = false;

            if (!HasActiveMarketOrders()
                && !this.OrderUpdateMultiCycleCache.HasElements()
                && !this.InOrderUpdateCycle())
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public bool HasActiveMarketOrders()
        {
            bool hasActiveMarketOrders = false;
            bool isActiveMarketOrder = false;
            int orderCount = this.OrderCount;

            for (int index = 0; index < orderCount; index++)
            {
                RealOrder order = null;

                if (this.TryGetByIndex(index, out order))
                {
                    isActiveMarketOrder = (order.IsMarket && !Order.IsTerminalState(order.OrderState));

                    if (isActiveMarketOrder)
                    {
                        hasActiveMarketOrders = true;
                        break;
                    }
                }
            }

            return hasActiveMarketOrders;
        }
    }
}
