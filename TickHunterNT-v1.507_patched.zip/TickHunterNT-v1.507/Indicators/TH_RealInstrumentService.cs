﻿using System;
using System.Collections;
using NinjaTrader.Code;
using NinjaTrader.Cbi;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealInstrumentService
    {
        private readonly ConcurrentDictionary<string, double> askPriceCache = new ConcurrentDictionary<string, double>();
        private readonly ConcurrentDictionary<string, double> bidPriceCache = new ConcurrentDictionary<string, double>();
        private readonly ConcurrentDictionary<string, double> lastPriceCache = new ConcurrentDictionary<string, double>();
        private readonly Dictionary<double, int> tickSizeDecimalPlaceCountCache = new Dictionary<double, int>();

        private string BuildKeyName(Instrument instrument)
        {
            string keyName = instrument.FullName;

            return keyName;
        }

        public double NormalizePrice(Instrument instrument, double price)
        {
            double newPrice = 0;
            int decimalPlaces = GetTickSizeDecimalPlaces(instrument.MasterInstrument.TickSize);

            string formatText = string.Concat("N", decimalPlaces);
            string stringPriceValue = price.ToString(formatText);
            newPrice = double.Parse(stringPriceValue);

            return newPrice;
        }
        public int GetTickSizeDecimalPlaces(double tickSize)
        {
            int decimalPlaceCount = 0;

            if (tickSize < 0) return decimalPlaceCount;

            if (tickSizeDecimalPlaceCountCache.ContainsKey(tickSize))
            {
                decimalPlaceCount = tickSizeDecimalPlaceCountCache[tickSize];
            }
            else
            {
                var parts = tickSize.ToString(CultureInfo.InvariantCulture).Split('.');

                if (parts.Length < 2)
                    decimalPlaceCount = 0;
                else
                    decimalPlaceCount = parts[1].TrimEnd('0').Length;

                tickSizeDecimalPlaceCountCache.Add(tickSize, decimalPlaceCount);
            }

            return decimalPlaceCount;
        }

        public static double ConvertTicksToDollars(Instrument instrument, int ticks, int contracts)
        {
            double dollarValue = 0;

            if (ticks > 0 && contracts > 0)
            {
                double tickValue = GetTickValue(instrument);
                double tickSize = GetTickSize(instrument);

                dollarValue = tickValue * ticks * contracts;
            }

            return dollarValue;
        }
        public static double GetTickValue(Instrument instrument)
        {
            double tickValue = instrument.MasterInstrument.PointValue * instrument.MasterInstrument.TickSize;

            return tickValue;
        }

        public static int GetTicksPerPoint(double tickSize)
        {
            int tickPoint = 1;

            if (tickSize < 1)
            {
                tickPoint = (int)(1.0 / tickSize);
            }

            return (tickPoint);
        }
        public static bool IsFutureInstrumentType(Instrument instrument)
        {
            bool isFuture = (instrument.MasterInstrument.InstrumentType == InstrumentType.Future);
            return isFuture;

        }
        public static double GetTickSize(Instrument instrument)
        {
            double tickSize = instrument.MasterInstrument.TickSize;

            return (tickSize);
        }

        public double GetLastPrice(Instrument instrument)
        {
            double lastPrice = 0;
            string keyName = BuildKeyName(instrument);

            if (!lastPriceCache.TryGetValue(keyName, out lastPrice))
            {
                if (instrument.MarketData != null && instrument.MarketData.Last != null)
                {
                    lastPrice = instrument.MarketData.Last.Price;
                }
                else if (instrument.MarketData != null && instrument.MarketData.Bid != null)
                {
                    lastPrice = instrument.MarketData.Bid.Price;
                }
                else
                {
                    lastPrice = 0;
                }
            }

            return lastPrice;
        }

        public double GetAskPrice(Instrument instrument)
        {
            double askPrice = 0;
            string keyName = BuildKeyName(instrument);

            if (!askPriceCache.TryGetValue(keyName, out askPrice))
            {
                if (instrument.MarketData != null && instrument.MarketData.Last != null)
                {
                    askPrice = instrument.MarketData.Last.Ask;
                }
                else if (instrument.MarketData != null && instrument.MarketData.Ask != null)
                {
                    askPrice = instrument.MarketData.Ask.Price;
                }
                else
                {
                    askPrice = 0;
                }
            }

            return askPrice;
        }

        public double GetBidPrice(Instrument instrument)
        {
            double bidPrice = 0;
            string keyName = BuildKeyName(instrument);

            if (!bidPriceCache.TryGetValue(keyName, out bidPrice))
            {
                if (instrument.MarketData != null && instrument.MarketData.Last != null)
                {
                    bidPrice = instrument.MarketData.Last.Bid;
                }
                else if (instrument.MarketData != null && instrument.MarketData.Bid != null)
                {
                    bidPrice = instrument.MarketData.Bid.Price;
                }
                else
                {
                    bidPrice = 0;
                }
            }

            return bidPrice;
        }

        public double SetAskPrice(Instrument instrument, double askPrice)
        {
            string keyName = BuildKeyName(instrument);

            double newPrice = askPriceCache.AddOrUpdate(String.Copy(keyName), askPrice, (oldkey, oldvalue) => askPrice);

            return newPrice;
        }

        public double SetBidPrice(Instrument instrument, double bidPrice)
        {
            string keyName = BuildKeyName(instrument);

            double newPrice = bidPriceCache.AddOrUpdate(String.Copy(keyName), bidPrice, (oldkey, oldvalue) => bidPrice);

            return newPrice;
        }

        public double SetLastPrice(Instrument instrument, double lastPrice)
        {
            string keyName = BuildKeyName(instrument);

            double newPrice = lastPriceCache.AddOrUpdate(String.Copy(keyName), lastPrice, (oldkey, oldvalue) => lastPrice);

            return newPrice;
        }
    }

}
